JD Arena Optimizer (JD-Optimiers) v5.9 - Mouse control + FPS booster for MSI App Player / BlueStacks 5 / BlueStacks X
==========================================================================================

HOW TO USE
  Double-click JD-Optimiers.exe (or Run-as-Admin.bat) - the app window opens.

  NEW IN 5.9 - Read-only mode instead of removal, AMD temperatures, BlueStacks X, Fair-Play check
    - Pass expired: if your Weekly Pass / plan isn't renewed within 3 days, the app no longer removes itself. It
      puts your PC back to normal once (Restore all - never while MSI App Player is open), deletes NO files, and
      opens in "Pass Expired - Read-Only Diagnostic Mode": FPS, ping, temperature, AI Doctor and Restore still work;
      the gold "Renew Weekly Pass (50 JD Points)" button opens jdesport.co.uk, then press "Check again".
    - GPU temperature from AMD Radeon cards too (AMD driver library); NVIDIA as before. The board / CPU sensor is
      used only on PCs with built-in graphics.
    - Ping is measured every 3 s. BlueStacks X is recognised; boost attaches when its Android player starts.
    - Panel scan (Max) also looks inside the emulator when its ADB access is on - read-only: the list of installed
      apps (memory editors, injectors, root / hooking apps), where the game was installed from and its files'
      sizes. It never switches ADB on and never changes anything. After the scan the verdict and any flagged app
      names (never your app list) go to JD Arena as your Fair-Play status, tied to the sealed report.
    - The game's name comes from your own emulator shortcut; the desktop icon is now "JD Arena Play".
    - Panel scan switches Windows' debug privilege on only while it runs, and off again after.

  NEW IN 5.8 - Record your gameplay smoothly
    - Recording while you play: OBS, Streamlabs, Bandicam, XSplit, Medal and Fraps are found automatically during
      Boost and given above-normal CPU and high GPU priority, so the video keeps up with the game. App Sleep never
      slows a recorder. Everything goes back to normal when Boost stops.
    - Xbox Game Bar: Win+Alt+R recording works again. Only the always-on background capture ("Record what
      happened"), the part that costs FPS, stays off. (5.7 and older switched Game Bar capture off completely.)
    - Session report: a "Recording" line, and if the game dipped while you recorded, encoder advice (use the hardware
      encoder - NVENC / AMD / QuickSync - at 60 FPS).

  NEW IN 5.7 - Why it stuttered, smarter FPS cap, safer sign-in
    - Session report: "FPS drops" counts the seconds well under your average and says what was going on at that
      moment - GPU too hot / power limit, on battery, CPU full, or which app was using the graphics card.
    - Smart cap: on a 60-75 Hz screen, if a 120+ cap can't be held, the report suggests 90 (or 60) - steadier frames,
      less heat. Advice only; you change the cap yourself with MSI App Player closed.
    - Tips from players with the same graphics card (once enough JD players have sent reports): which renderer and
      FPS cap give them the steadiest frames.
    - Live FPS works even if you downloaded only the .exe: PresentMon now comes inside the app.
    - Your sign-in is tied to this PC: a copied sign-in file doesn't work on another PC (sign in there instead).
    - Your session history (FPS, 1% low, temperature, drops) shows on your JD profile.

  NEW IN 5.6 - Terms once, no data questions
    - First start shows the JD-Optimiers terms once (I agree / Read full terms / Exit). The download page asks for
      the same agreement before the download.
    - No more "Share?" / "Send your PC report?" questions. After each session - and when you close the app or Windows
      shuts down (waits 3 s at most) - it sends by itself the anonymous FPS summary and the private PC report to
      your JD account. Never files, passwords, game data or mouse / aim numbers.
    - Both stay switchable in the tray menu. If you said "No thanks" before, that choice is kept (stays off).
    - Needs a Weekly Pass (jdesport.co.uk/pass) as well as Optimizer Pro / Max. If either ends, the app warns you at
      start how many days are left. Not renewed within 3 days: it runs Restore all and switches to Read-Only
      Diagnostic Mode (5.9 - before 5.9 it removed its own files). Only when online and never while MSI App Player
      is open.

  NEW IN 5.5 - Private PC report (asked once)
    - After a session JD asks once: "Send your PC report to JD?" Yes = after each session your PC (CPU, graphics,
      RAM, score), MSI App Player's settings and how the session ran (FPS, Stable-FPS, the likely reason for drops)
      go to your own JD account. Only you and the JD admin can see it; ZULU uses it to answer your FPS questions.
      No files, no mouse / aim numbers. Tray > "Send my PC report to my JD account (private)" turns it on/off.

  NEW IN 5.4 - Stable FPS, a smarter PC rating, headshot coach, back to normal when you stop
    - PC score 0-100 (CPU: threads + how new it is; graphics: the real model - RTX/GTX/RX/Iris Xe/Radeon 680M...;
      RAM). Low < 38 <= Mid < 62 <= High. Shown in Apply best profile: "PC score 72 (CPU 92, graphics 52, RAM 80)".
    - Stable FPS: after every session the report says how much of your playing time stayed at cap-5 .. cap
      (e.g. "Stable 90: 92% at 85-90 FPS") and, when it didn't, the most likely reason from your own numbers
      (charger, heat, graphics card maxed, CPU limit, other apps on the GPU). Also in the "Boost stopped" notice.
    - Headshot coach (Max, play coach on): counts up-drags while firing. After a session: how many went past the
      head and how many needed a second push. After 2 weeks (150+ drags) it can suggest Aim Y -8% / +8%
      (turning / Aim X untouched). Mouse feed is read-only raw input - no hook, no added mouse delay.
    - Laptop back to normal when you stop (tray, ON by default): power plan, window animations and transparency
      go back to yours; JD sets them again on the next Play.
    - JD trims its own memory every minute while you play (more RAM for the game).
    - Deep Optimize cleans more junk (crash dumps, error reports, Delivery Optimization cache, setup logs,
      MSI App Player logs) - and no longer deletes shader caches, which made the next match stutter.

  NEW IN 5.3 - Profile built from your PC (GPU-first) + update notice
    - Apply best profile now starts with a "Your PC" line (CPU, threads, RAM, graphics card, screen Hz) and picks:
        * Renderer: Vulkan on an NVIDIA / AMD graphics card (its driver does far less work on the CPU, so the card
          carries more of each frame); OpenGL on built-in graphics. Your play coach's proven pick still wins.
        * FPS cap from your screen: 120 on a 120 Hz+ screen with a graphics card, 90 otherwise, 60 on low-end.
        * Built-in graphics only: 720p (low-end) or 900p (mid-range) instead of 1080p - fewer pixels, more FPS.
        * ASTC textures never decoded on the CPU on PCs with 8 threads or fewer.
    - Windows tweaks: "Optimizations for windowed games" ON (flip model - less GPU copying, lower latency).
      Restore all puts it back.
    - Pre-match check: apps using your graphics card (browser video, overlays, live wallpapers...) are listed;
      "Close apps..." asks app by app, so the game gets the GPU.
    - Updates while the app stays open: checked every 30 min; "Update now?" when one is out - never mid-match
      (during a boost it waits and asks when the boost ends). Yes = downloads, checks SHA-256, reopens itself.

  NEW IN 5.2 - Apply works with the game open (asks first)
    - Apply best profile, Aim Studio, play-coach tips, DPI and Android boost no longer stop at "close MSI App
      Player first". If it is closed, JD applies at once. If it is open, changes that work live (the Windows
      mouse curve, Extreme mode) apply straight away; emulator settings and game controls - which MSI App Player
      only reads when it starts, and overwrites when it closes - ask once: "Close MSI App Player, apply, and open
      it again?" (default No - closing it ends a match, so only say Yes in the lobby).
    - On Yes: MSI App Player is closed politely (forced only if it hangs ~15 s), the change is applied, and it
      opens again straight into your game. A running Boost stops and Auto mode starts it again.

  NEW IN 5.1 - Adaptive aim curve fixed (Aim Studio > Adaptive)
    - The custom curve now uses Windows' own mouse-speed points: before, the default curve made the pointer
      about 3x faster at normal speeds and only the first handle did anything.
    - Each handle (slow / medium / fast / flick) sets 0.25x - 2.5x of Windows' speed; 1x everywhere = exactly
      Windows' default curve. The curve always rises, so the pointer never slows down as you move faster.
    - Applying a normal (non-adaptive) aim no longer resets a mouse curve JD didn't write.
    - Your curve is remembered and shown again next time you open Aim Studio.

  NEW IN 5.0
    - Live FPS: while Boost runs, the Stop banner shows FPS now, FPS while the camera turns (Max, play coach
      on) and hitches (frames over 50 ms).
    - Pre-match check: pressing Play checks the charger, mouse acceleration, the emulator profile, macro keys,
      heavy apps and Wi-Fi. All fine = plays at once. Otherwise "Fix & play" fixes the safe ones (never with
      the emulator open), "Close apps..." asks app by app, "Play anyway" plays as is.
    - Smarter "Apply best profile": also sets the CPU cores this CPU can give and - when the play coach has
      proven it on your own sessions - the renderer and cores that turned smoothest. Shows every change first.
    - Network (Extreme mode): pauses Windows Update / Store background downloads (Delivery Optimization, BITS)
      and Wi-Fi power saving while you play, all put back after. Weak Wi-Fi is pointed out (signal %); a faster
      DNS is NOT offered - it doesn't change in-match ping.
    - Share anonymous FPS stats (tray menu, asked once, OFF unless you say yes): one summary per session - FPS,
      emulator settings, PC model - under a random ID made on this PC. No account, name or mouse numbers. Used
      to find the settings that run best on each kind of PC.

  NEW IN 4.9 - Optimizer Max
    - Play coach (Max engine > Play coach, OFF until you press Start learning): while Boost runs it
      learns from your own matches - how you drag and flick, how often a flick overshoots (you correct
      back the other way), how often you run out of mousepad, and your FPS while the camera turns vs
      standing still. After 7 days (5+ sessions of 5+ min) it turns that into suggestions: smoother
      renderer / FPS cap / cores from YOUR numbers, Extreme mode when the CPU holds you back, Aim X up or
      down 8%. It asks before every change and only changes things with MSI App Player closed.
      It reads the mouse like any mouse software (never the keyboard, nothing inside the game) and keeps
      the numbers on this PC only (JD-Optimiers-coach.csv). Console: --coach.
    - GPU priority: while boosting, the emulator gets HIGH GPU scheduling priority (like CPU priority, for
      the graphics card), so browser / Discord / overlay GPU work waits behind your frames.

  NEW IN 4.8 - Optimizer Max
    - DPI & aim: changing the emulator DPI now also rescales your Aim X so a full turn keeps the same
      mouse distance (up/down % is kept). Run the 360-degree aim test to confirm on your PC.
    - Android boost (OPTIONAL, OFF until you turn it on, Max): uses ADB to turn Android animations off,
      close BlueStacks' store / game-center apps and the Play Store, and send the game one memory trim
      while it loads. It switches ADB access on in MSI App Player; Turn OFF / Restore all puts everything
      back. Garena's anti-cheat runs inside Android and its rules on ADB are not public - use at your own risk.
    - Fixed: correct plan prices in the app (Pro 49 / Max 99 points), "Aim..." button label.

  NEW IN 4.7 - smoother, safer boost
    - App Sleep no longer freezes apps: while you play they run in Windows efficiency mode at the
      lowest priority with their RAM trimmed, so Discord-style audio/network never breaks. They are
      put back exactly as they were when you Alt-Tab out or stop Boost.
    - Extreme mode: also lets the CPU turbo (max state 100%) and stops USB power saving for your
      mouse/keyboard; on 6+ core PCs the emulator is kept off CPU core 0 (Windows interrupt work).
      All of it goes back when the boost ends.
    - Network: Windows multimedia network throttling OFF for games (after a restart; Restore undoes it).
    - Deep clean's cache + RAM steps are built in now (faster, no PowerShell window).
    - Start with Windows uses Task Scheduler directly (no hidden command window).
    - OPTIMIZER MAX: tray menu > "Max engine" - set the emulator DPI (backed up), a 360-degree AIM TEST
      (press F8, turn once around, F8 again: it measures your real turn distance before and after a
      DPI change and tells you the exact Aim X that keeps your aim the same), and BlueStacks engine
      shader-cache cleaning. 240 FPS is a Max feature for Pro plans bought from now on (existing Pro
      plans keep it until they renew).
    - Panel scan reports get a SIGNED server receipt: --verify now catches a report that was edited
      and re-sealed. (It proves the report wasn't changed after the scan; no PC-side check can prove
      the scan itself was honest.)

  NEW IN 4.6 - Aim Studio: Adaptive custom curve
    - Turn on Adaptive in Aim Studio to shape your OWN acceleration curve - drag the 5 points
      like pro mouse software. It writes the Windows pointer-acceleration curve (backed up;
      Restore puts it back). Off by default. Note: emulator aim that uses raw input ignores the
      Windows curve, so for pure in-game flicks keep it off - it shapes the desktop cursor and
      games that use the Windows pointer.

  NEW IN 4.5 - Aim Studio: drag the curve + profiles
    - Drag the curve in Aim Studio to set your sensitivity live (the slope = your aim speed).
    - Save your setups as profiles (loadouts) and tap to switch - great for different ranges.

  NEW IN 4.4 - Aim Studio
    - New "Aim..." button opens Aim Studio: set your own Aim X (sensitivity) and Y (up/down %),
      see a live acceleration curve (straight = steady aim, curved = fast flicks over-turn), and
      turn Windows pointer precision on/off. "Recommended" sets the proven values. Writes Free
      Fire's Game controls (backed up; close MSI App Player first). Restore puts them back.
  NEW IN 4.3 - one full optimizer: Deep clean built in
    - New "Deep clean" button optimizes the WHOLE PC, not just the game: clears temp / cache /
      shader junk, frees standby RAM, and turns off telemetry / Copilot / Recall background
      tasks. A System Restore point is made first and "Restore" undoes the Windows changes.
    - Tray menu > "Optimization suite" opens JD-Sentinel - the full tool: safe debloat, startup
      & WMI audit, Microsoft Defender hardening (ASR in audit mode), game service-boost with
      snapshot restore, and an alert-only ransomware/exploit watchdog. Everything reversible.
    - The package now includes JD-Sentinel (JD-Sentinel.bat / .ps1). See README-SENTINEL.md.

  NEW IN 4.2 - any game, performance modes, lower prices
    - New prices: Optimizer Pro 49 points, Optimizer Max 99 points (30 days). Max now also gives
      a 30-day Pro squad effect each time you buy, early entry to marked tournaments/rooms, and a
      verified checkmark next to your name - on top of Panel scan.
    - Boost ANY PC game, not just your emulator game: press "Games" to add a game's .exe, or leave
      auto-detect on and any full-screen game is boosted automatically.
    - Performance Mode button:
        Balanced - the normal boost.
        Extreme  - pauses Windows background services (SysMain, Search, telemetry) and runs the
                   CPU at full speed while you play (plugged in). More heat - keep the PC cool.
                   Needs Administrator. Everything is put back when the boost ends.
        Potato   - Extreme, plus "Apply best profile" drops the emulator to 1280x720 / 60 FPS for
                   weak PCs.
    - Your plan shows as a PRO / MAX chip in the title bar.

  NEW IN 4.1 - JD Esports Arena account + Optimizer Pro / Max
    - JD-Optimiers now needs a plan on your JD Esports Arena account (jdesport.co.uk), paid with
      JD points (1 point = Rs 1, loaded on the site's wallet with eSewa):
        Optimizer Pro   49 points / 30 days - everything except Panel scan
        Optimizer Max   99 points / 30 days - everything + Panel scan
      Buy at https://jdesport.co.uk/optimizer/ (sign in first). Buying again adds 30 days.
    - Sign in once per PC: the app shows a code (like ABCD-2345) and opens the website - sign in
      there (email or Google), check the code matches, press "Link this PC". No password is typed
      into the app. 2 PCs per account; unlink old PCs on the plans page.
    - The plan is checked when the app starts. Without internet it keeps working for up to 3 days
      after the last check (while the plan is active).
    - No plan? The app's start screen still lets you "Restore settings" (puts back everything
      JD-Optimiers changed). Tray menu > "Sign out of this PC" unlinks it.
    - The console version (JD-Optimiers-Console.exe) is no longer part of the download.

  NEW IN 4.0 - JD Esports logo + automatic updates
    - The JD Esports Arena logo (same as jdesport.co.uk) in the window, splash, tray and app icon.
    - Download / reinstall: https://jdesport.co.uk/optimizer/
    - Updates are required: at every start the app checks jdesport.co.uk. If a new version is out,
      a pop-up offers "Update now" (or exit). It downloads, checks the file (SHA-256), swaps itself
      and reopens in a few seconds. It only checks when the app starts - never during a match.
      If the site can't be reached (no internet), the app still opens and says so in the feed.

  NEW IN 3.9 - JD Esports gold look + more GPU for graphics
    - New colors matching jdesport.co.uk: near-black background, gold buttons with dark text,
      Bahnschrift Condensed headings (closest Windows font to the site's Barlow Condensed).
    - Windows tweaks (also run by Play the first time) now add, when the Administrator prompt
      is accepted: Hardware-accelerated GPU scheduling ON (needs a PC restart) and the Windows
      "Games" scheduler profile (GPU priority 8, scheduling High). Restore all undoes both.
    - "Apply best profile" on a high-end PC with a graphics card, on the charger, also raises
      the emulator resolution 1600x900 / 1280x720 -> 1920x1080 (sharper, more GPU work). It is
      listed in the confirm box; MSI App Player must be closed. Restore all puts it back.
    - The game's own Graphics level (Smooth / Standard / Ultra) is set inside the game by you.

  NEW IN 3.8 - real FPS numbers
    - Live FPS while you play (uses PresentMon from the fps-monitor folder - it reads
      Windows' frame events, nothing inside the game). Needs the Administrator prompt.
    - The session report now shows FPS: average, 1% low (the dips you feel as lag) and
      stutters per minute - and compares with your last match:
        "vs last session: FPS 75 -> 84, 1% low 28 -> 52"
      plus which settings changed in between. All sessions: Console --history
    - Renderer test: with MSI App Player closed, Console --renderer vulkan (or opengl),
      play one match, compare. --astc off|software the same way. Restore all undoes it.
    - Laptop checks: report warns when you played on battery or the NVIDIA card slowed
      itself down because of heat.
    - Console --pc-check (changes nothing): power mode, GPU scheduling, Memory Integrity,
      emulator graphics, macro keys. JD-Optimiers will NOT turn off Memory Integrity -
      it only tells you.
    - Console --remove-macros lists your macro keys (ban risk); --remove-macros yes
      deletes them from the game's emulator controls (MSI App Player closed, backup made,
      Restore all puts them back). REDRAGON rapid-fire must be changed in the REDRAGON app.
    - Ping line now says what it pings. Matches run over UDP, which Windows cannot show,
      so the ping is a guide - not the exact match ping.

  NEW LOOK (3.7)
    - JD brand look: deep navy with the JD gradient (cyan -> blue -> violet) and a
      matching JD icon.
    - The log is now an easy-to-read activity list: green check = done, yellow ! =
      look at this, red x = problem. Scroll with the mouse wheel; right-click it to
      copy everything.

  NEW IN 3.7 - Panel scan finds more
    - Programs run in the last days, even if closed or deleted before the scan
      (Windows activity log - needs the Administrator prompt accepted).
    - Local proxy and hosts-file redirects of the game's servers.
    - DEEP SCAN (Shift+click Panel scan, or --scan deep): also lists the DLLs loaded
      inside the emulator and flags unsigned ones (injected panels). This reads the
      emulator's DLL list like Task Manager does - no game data - so it only runs
      when you ask for it.

  NEW IN 3.6
    - Point at any button: the strip above the log says what it does. Not pointing
      at anything: "Setup check" says what to fix next (green = all good).
    - Knows your PC: Low-end / Mid-range / High-end, laptop or desktop (shown at
      the top). The best profile, FPS choice and tips fit that PC - e.g. 2 emulator
      cores + 60 FPS on a 4 GB laptop, no "dedicated GPU" on PCs without one.
    - Temperature tile also works on AMD / Intel PCs ("system °C").
    - Windows tweaks also bypass fullscreen optimizations and stop Store apps
      running in the background (their notifications stop - Restore all undoes it).
    - Clearer names: "Mouse accel (keep OFF)", "Apply best profile".

  NEW IN 3.5
    - Start with Windows now uses Task Scheduler: no admin prompt at login, also
      on battery. Old "Start with Windows" entries are moved over automatically.
    - Scan reports end with "Seal: XXXX-XXXX-XXXX-XXXX". Check one with
        JD-Optimiers-Console.exe --verify "JD-Scan-....txt"
      VALID = untouched, INVALID = someone edited it. (Shows edits; a determined
      hacker could still fake one - for real certainty, scan the PC yourself.)
    - Mouse card shows the emulator aim values: "Aim X 2.04 · Y 91%".
    - Panel scan button shows the last result (clean / warning / CHEAT).
    - Finds MSI App Player / BlueStacks even when installed on another drive.

  NEW IN 3.4
    - Starts as administrator by itself (one Windows prompt). Say No and it still
      runs, only RAM purge / full panel scan / priority may be limited.
      Starting it again while it runs just brings the window forward (no prompt).
    - Boost clears the Windows standby RAM once, and stops Windows 11 power
      throttling (EcoQoS) for HD-Player.exe while it has HIGH priority.
    - Ping tile pings the server the emulator is connected to ("game server");
      if it ignores ping, or there is no connection yet, 1.1.1.1 ("internet").
    - Laptop profile also sets High FPS ON, VSync OFF, Prefer dedicated GPU ON,
      and has a 240 FPS choice (only useful on 144 Hz+ screens).
    - Windows tweaks: HD-Player.exe gets "DPI scaling: Application" and
      fullscreen optimizations OFF (its Properties > Compatibility settings).
    - Aim fix keeps a custom up/down ratio (40-250%) and only turns emulator
      mouse acceleration OFF. Set X / Y yourself: Console --aim-xy 2.04 0.91
    - Only scripts that fire several taps count as macros (helper scripts don't).

  NEW IN 3.2 / 3.3 - glass look, Panel scan, app icon
    Dark "liquid glass" window (frosted panels over a soft orange / purple glow,
    iOS-style switches that slide) and an animated JD splash when the app opens
    (click it to skip). It looks the same whether Windows transparency is on or off.
    The window stops redrawing while the game is in front, so it costs no FPS.
    No splash when it starts in the tray (Start with Windows / --tray).

  PLAY (big gold button - shows your game's name from its emulator shortcut)
    optimizes Windows -> opens MSI App Player straight into your game ->
    Boost + App Sleep while you play -> when you close MSI App Player it
    stops by itself, wakes your apps and writes a SESSION REPORT in the log.
    "Desktop shortcut" makes an icon "JD Arena Play" that does the same.

  AUTO MODE (zero clicks)
    Turn on "Auto boost when game opens" (and "Start with Windows" if you like).
    JD-Optimiers then waits in the system tray. Open MSI App Player any way you
    like -> boost starts by itself -> close it -> boost stops, apps wake up and
    a Windows notification shows your match summary (time, GPU, temp, ping).
    With Auto mode on, the X button hides the window to the tray.
    Tray icon: click = open, right-click = Play / Auto on-off / Exit.

  LEFT SIDE
    Boost only        - boost without launching the game (press again to stop)
    Restore all       - puts back everything JD-Optimiers changed
    Live tiles        - CPU, GPU load (which GPU runs the game), GPU temp, ping,
                        each with a 60-second graph; RAM bar; apps asleep
    Log               - what the app did + session report and advice

  RIGHT SIDE
    Mouse sensitivity - drag the slider or use - / +, presets, pointer precision
    Gaming boost      - App Sleep, Auto boost, Start with Windows, sleep list,
                        Windows tweaks (your choices are remembered)
    Laptop profile    - pick 60 / 90 / 120 FPS and apply (emulator must be closed)

  FILES
    JD-Optimiers.exe          the app window
    JD-Optimiers-Console.exe  same features in a text menu + command line
    gui.c / jd_optimiers.c    source code, build.bat rebuilds both

LIVE STATS WHILE PLAYING (console shows the same in one line)
    - RTX 3050 = the game is on your NVIDIA card (good). "Radeon" = it is not.
    - 62C = NVIDIA GPU temperature ("HOT" at 85C+)
    - Ping = the game server the emulator is connected to, or 1.1.1.1 when that
      server ignores ping (the tile says which).
      If Net jumps/LOST while the game lags, the lag is the internet, not FPS.

  SESSION REPORT (after each Play / Boost)
    Average/peak CPU, RAM, GPU load, GPU temperature and ping, plus advice:
    game on the wrong GPU, GPU maxed out (lower FPS cap), running hot,
    CPU/RAM too busy, or internet spikes.

WHAT IT CHANGES (Play applies the Windows tweaks automatically the first time)
  - Mouse pointer speed (1-20, 10 = default) and Enhance Pointer Precision
  - Power plan -> Ultimate / High Performance
  - HD-Player.exe priority -> HIGH (never Realtime)
  - 1 ms system timer + no sleep while Boost Mode is running
  - Windows gaming tweaks: Game Mode ON, Xbox Game Bar recording OFF,
    emulator forced onto the high-performance GPU, transparency and
    window animations OFF, pointer trails OFF
  - Closes background apps only if you answer "y" for each one
  - APP SLEEP (in Boost Mode): apps on your sleep list are slowed right down
    (Windows efficiency mode, lowest priority) and their RAM is freed while the
    game window is in front. Alt-Tab out or stop Boost and they are put back. Edit the list in
    Optimizer > [7] or in JD-Optimiers-sleep-list.txt. Discord/Spotify are
    not on it by default so voice chat and music keep working.
    If the PC crashes while apps are asleep, just open JD-Optimiers again
    (or run JD-Optimiers.exe --wake) and they are woken up automatically.

  - PANEL SCAN (button "Panel scan", Console [7] or --scan) - for players and
    tournament organizers. Looks for signs of cheat panels and hardcode hacks:
      * windows drawn over the game, especially ones hidden from screenshots
        (how ESP / aim panels draw)
      * programs that can write into the emulator's memory (how injected panels
        work) - needs admin: start with Run-as-Admin.bat for a full scan
      * cheat tools / unsigned "panel" programs running from Downloads or Temp
      * Windows test-signing or debug mode (kernel-level panels need it)
      * emulator root / ADB on, macro keys, mouse rapid-fire buttons
      * modded APK / OBB files in Downloads, Desktop and the emulator shared folder
    Result: NO SIGNS FOUND / PARTIAL SCAN (some checks could not run) / WARNING /
    CHEAT SIGNS FOUND, with the evidence for each finding. A report file
    JD-Scan-<date>-<time>.txt is saved next to the app (PC name, user, time).
    Open the game first so the overlay and write-access checks can run.
    LIMIT: game files inside the emulator cannot be checked from Windows - the
    scan shows warning signs, it cannot prove the game files are clean.
    It only reads; it never opens the game's memory and never changes anything.

  - AIM FIX (button next to Pointer precision, or Console --aim [fix]):
    checks Windows mouse settings, the emulator screen size, your emulator
    game controls and the REDRAGON mouse app profile. It fixes only aim feel:
    up/down aim set to 100% of left/right (a lower value makes drags to the head
    fall short, so aim stays low) and emulator mouse acceleration OFF.
    MSI App Player must be closed for that; backup JD-Optimiers-keymap.cfg.bak,
    Restore all puts it back. Screen size is only checked (your buttons are placed
    for it). It warns about macros (script keys, REDRAGON rapid-fire buttons) because
    Garena bans them - it never adds macros or aim help. REDRAGON settings are only
    read; it opens the REDRAGON app so you change them there.
  - LAPTOP PROFILE (only if you choose it): the emulator's RAM and FPS cap
    in C:\ProgramData\BlueStacks_msi5\bluestacks.conf - the same values as
    its Settings screen. RAM is set to what the game needs (4 GB on a 16 GB
    PC) so Windows keeps the rest; you pick the FPS cap (60 / 90 / 120).
    Nothing else in that file is touched. Original saved as
    JD-Optimiers-bluestacks.conf.bak and put back exactly by Restore.
  - BOOST MODE shows live CPU %, RAM used and which GPU the game is on + its load,
    so you can see the NVIDIA card doing the work.

  Your original settings are saved to JD-Optimiers-backup.ini the first time
  something is changed. Restore uses that file.

SAFE FOR ANTI-CHEAT
  It only changes Windows settings, other apps (browsers, launchers...) and,
  if you choose Laptop profile, the emulator's RAM/FPS settings (same as its
  Settings screen). It never opens, reads or changes the game or the
  emulator's memory, and the emulator is never paused. No macros, no aim or recoil help,
  no injected code - it is the same as changing settings in Windows yourself.

COMMAND LINE
  JD-Optimiers-Console.exe --status | --mouse N | --accel on|off | --optimize | --tweaks | --play | --shortcut | --boost | --wake | --profile | --aim [fix] | --aim-xy X Y | --scan [deep] | --verify FILE | --pc-check | --fps [secs] | --history | --renderer opengl|vulkan | --astc off|software | --remove-macros [yes] | --restore

REBUILD
  build.bat   (icon + version info come from res\jd.rc / res\jd.ico)
    (needs GCC: winget install BrechtSanders.WinLibs.POSIX.UCRT)
