#Requires -Version 5.1
<#
    JD-Sentinel - Windows optimisation & behavioural-security companion for JD-Optimiers
    ====================================================================================
    A single, dependency-free PowerShell engine (no Electron, no Python, no background
    bloat) that replicates the useful low-level mechanisms of the big tools - but SAFE:

      * Every change is recorded first and can be undone with "Restore everything".
      * --AuditOnly (and the "Audit" menu items) only READ and report - they change nothing.
      * The behavioural watchdog ALERTS; it never kills or suspends a process by itself, so it
        can never freeze your game, emulator or a backup/updater on a false alarm.
      * Attack-surface-reduction (ASR) rules go on in AUDIT mode first, so nothing breaks until
        you choose to enforce them.

    Modules
      1  Debloat & telemetry + Ultimate Performance power plan      (reversible)
      2  Startup / persistence auditor - Run keys, IFEO, tasks, WMI (read-only; signatures)
      3  Standby-memory flush + targeted cache cleanup              (native NtSetSystemInformation)
      4  Game / heavy-workload service boost with JSON snapshot      (reversible)
      5  Microsoft Defender hardening + ASR (audit first) + HVCI     (reversible)
      6  Behavioural watchdog - ransomware canary + exploit chains   (ALERT ONLY)
      7  WMI & UEFI (EFI System Partition) persistence scan          (read-only)

    Usage
      JD-Sentinel.bat                         interactive menu (self-elevates)
      pwsh -File JD-Sentinel.ps1 -AuditOnly    menu, but every destructive item is a dry run
      pwsh -File JD-Sentinel.ps1 -Action <name>   run one module headless, e.g.:
           debloat | restore | memory | clean | services-boost | services-restore
           defender | defender-enforce | autoruns | scan | watch

    Safety: run as Administrator. It makes a System Restore point and backs up every registry
    key and service state it touches, under .\JD-Sentinel-backups\<timestamp>\.
#>

[CmdletBinding()]
param(
    [switch]$AuditOnly,
    [ValidateSet('menu','debloat','restore','memory','clean','services-boost','services-restore',
                 'defender','defender-enforce','autoruns','scan','watch')]
    [string]$Action = 'menu',
    [string[]]$BoostApps,            # extra service names to add to the boost snapshot (advanced)
    [switch]$NonInteractive
)

$ErrorActionPreference = 'Stop'
$script:Root        = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:StampDir    = $null
$script:BackupBase  = Join-Path $script:Root 'JD-Sentinel-backups'
$script:SnapshotDir = Join-Path $script:Root 'JD-Sentinel-state'   # live state that Restore reads
$script:LogFile     = Join-Path $script:Root 'JD-Sentinel.log'
$script:DryRun      = [bool]$AuditOnly

# ── console + log ────────────────────────────────────────────────────────────
function Write-Line {
    param([string]$Text, [string]$Level = 'info')
    $color = switch ($Level) { 'ok' {'Green'} 'warn' {'Yellow'} 'err' {'Red'} 'head' {'Cyan'} default {'Gray'} }
    $tag   = switch ($Level) { 'ok' {'[OK]  '} 'warn' {'[!]   '} 'err' {'[X]   '} 'head' {''} default {'      '} }
    Write-Host ($tag + $Text) -ForegroundColor $color
    try { Add-Content -LiteralPath $script:LogFile -Value ("{0} {1} {2}" -f (Get-Date -Format 's'), $Level.ToUpper(), $Text) -Encoding utf8 } catch {}
}
function Head($t) { Write-Host ''; Write-Line "== $t ==" 'head' }
function Act($t)  { if ($script:DryRun) { Write-Line "WOULD: $t" 'warn' } }  # dry-run notice helper

# ── safety pre-flight ─────────────────────────────────────────────────────────
function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}

function Initialize-Session {
    New-Item -ItemType Directory -Force -Path $script:BackupBase, $script:SnapshotDir | Out-Null
    $script:StampDir = Join-Path $script:BackupBase (Get-Date -Format 'yyyyMMdd-HHmmss')
    if (-not $script:DryRun) { New-Item -ItemType Directory -Force -Path $script:StampDir | Out-Null }
}

function New-RestorePoint {
    if ($script:DryRun) { Act 'create a System Restore point'; return }
    try {
        # System Restore throttles to one checkpoint per ~24h; clear that limit for this run.
        New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore' `
            -Name 'SystemRestorePointCreationFrequency' -Value 0 -PropertyType DWord -Force -ErrorAction SilentlyContinue | Out-Null
        Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
        Checkpoint-Computer -Description 'JD-Sentinel' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        Write-Line 'System Restore point created.' 'ok'
    } catch {
        Write-Line "Could not create a System Restore point ($($_.Exception.Message.Trim())). Continuing - per-change backups are still made." 'warn'
    }
}

# Back up a whole registry key to a .reg file before changing it (reg.exe export = exact, re-importable).
function Backup-RegKey {
    param([string]$Path)   # e.g. HKLM\SOFTWARE\...
    if ($script:DryRun) { return }
    $safe = ($Path -replace '[\\:]', '_')
    $file = Join-Path $script:StampDir "$safe.reg"
    & reg.exe export $Path $file /y *> $null
}

function Save-Json {
    param([string]$Name, $Object)
    if ($script:DryRun) { return }
    $Object | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $script:StampDir $Name) -Encoding utf8
    # also keep the latest under the stable state dir so Restore can find it without a timestamp
    $Object | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $script:SnapshotDir $Name) -Encoding utf8
}

# Records each value's prior state (existed? old data?) so Restore can revert exactly - even values we create.
$script:RegUndo = [System.Collections.Generic.List[object]]::new()
function Set-Reg {
    param([string]$Path, [string]$Name, $Value, [string]$Type = 'DWord')
    if ($script:DryRun) { Act "set $Path\$Name = $Value"; return }
    $old = $null; $existed = $false
    try { $cur = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop; $old = $cur.$Name; $existed = $true } catch {}
    $script:RegUndo.Add([pscustomobject]@{ Path=$Path; Name=$Name; Existed=$existed; Old=$old; Type=$Type })
    if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
    New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
}

# ── MODULE 1: debloat + telemetry + Ultimate Performance ──────────────────────
# Per-user / per-machine toggles only, each backed up. Nothing here breaks Windows Update or the Store.
$script:TelemetryServices = @('DiagTrack','dmwappushservice')

function Invoke-Debloat {
    Head 'Debloat & telemetry'
    # services -> snapshot their current state, then disable
    $snap = @()
    foreach ($svc in $script:TelemetryServices) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if (-not $s) { continue }
        $cfg = Get-CimInstance Win32_Service -Filter "Name='$svc'" -ErrorAction SilentlyContinue
        $snap += [pscustomobject]@{ Name = $svc; StartType = $cfg.StartMode; State = $s.Status.ToString() }
        if ($script:DryRun) { Act "stop and disable service $svc"; continue }
        try {
            if ($s.Status -eq 'Running') { Stop-Service $svc -Force -ErrorAction SilentlyContinue }
            Set-Service  $svc -StartupType Disabled -ErrorAction SilentlyContinue
            Write-Line "Telemetry service $svc stopped and disabled." 'ok'
        } catch { Write-Line "Could not change $svc : $($_.Exception.Message.Trim())" 'warn' }
    }
    Save-Json 'debloat-services.json' $snap

    # registry toggles (telemetry off, consumer experiences off, Copilot/Recall off, search Bing off)
    $reg = @(
        @{ P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection';                 N='AllowTelemetry';                     V=0 },
        @{ P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent';                   N='DisableWindowsConsumerFeatures';     V=1 },
        @{ P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot';                 N='TurnOffWindowsCopilot';              V=1 },
        @{ P='HKCU:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot';                 N='TurnOffWindowsCopilot';              V=1 },
        @{ P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsAI';                      N='DisableAIDataAnalysis';              V=1 },  # Recall
        @{ P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search';                   N='BingSearchEnabled';                  V=0 },
        @{ P='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search';                   N='CortanaConsent';                     V=0 },
        @{ P='HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search';                 N='AllowCortana';                       V=0 }
    )
    foreach ($r in $reg) { Set-Reg -Path $r.P -Name $r.N -Value $r.V }
    if (-not $script:DryRun) {
        Save-Json 'debloat-reg.json' @($script:RegUndo)
        Write-Line 'Telemetry / Copilot / Recall / Bing-search registry policies set (reversible).' 'ok'
    }

    Enable-UltimatePlan
}

function Enable-UltimatePlan {
    Head 'Ultimate Performance power plan'
    $ult = 'e9a42b02-d5df-448d-aa00-03f14749eb61'
    if ($script:DryRun) { Act 'unlock + activate the Ultimate Performance plan and disable PCIe link-state power management'; return }
    # remember the current plan so Restore can switch back
    $cur = (powercfg /getactivescheme) 2>$null
    if ($cur -match '([0-9a-fA-F-]{36})') { Save-Json 'power-plan.json' @{ Previous = $Matches[1] } }
    & powercfg -duplicatescheme $ult *> $null     # unlocks it if hidden (harmless if already present)
    & powercfg /setactive $ult *> $null
    if ($LASTEXITCODE -eq 0) { Write-Line 'Ultimate Performance plan active.' 'ok' }
    else { Write-Line 'Could not activate Ultimate Performance (older Windows build?). High Performance is a good fallback.' 'warn' }
    # PCIe Link State Power Management OFF on the active plan (both AC and DC)
    & powercfg /setacvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 0 *> $null
    & powercfg /setdcvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 0 *> $null
    & powercfg /setactive SCHEME_CURRENT *> $null
    Write-Line 'PCIe Link State Power Management disabled.' 'ok'
}

# ── MODULE 2: startup / persistence auditor (read-only) ───────────────────────
function Get-SignatureTag {
    param([string]$FilePath)
    if (-not $FilePath -or -not (Test-Path $FilePath)) { return 'missing' }
    try {
        $sig = Get-AuthenticodeSignature -LiteralPath $FilePath -ErrorAction Stop
        if ($sig.Status -ne 'Valid') { return "UNSIGNED/$($sig.Status)" }
        if ($sig.SignerCertificate.Subject -match 'Microsoft') { return 'Microsoft' }
        return "signed: $(( $sig.SignerCertificate.Subject -split ',')[0] -replace 'CN=','')"
    } catch { return 'unknown' }
}
function Resolve-Exe { param([string]$Cmd)   # pull the .exe path out of a command line (handles spaces in paths)
    if (-not $Cmd) { return $null }
    $c = $Cmd.Trim()
    if ($c.StartsWith('"')) { return ($c -split '"')[1] }
    $m = [regex]::Match($c, '(?i)^(.*?\.(exe|com|scr|bat|cmd|dll|pif))\b')  # up to the first executable extension, spaces allowed
    if ($m.Success) { return $m.Groups[1].Value }
    return ($c -split ' ')[0]
}

function Invoke-Autoruns {
    Head 'Startup & persistence audit (read-only)'
    $flags = 0
    $runKeys = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'
    )
    Write-Line 'Run / RunOnce keys:'
    foreach ($k in $runKeys) {
        if (-not (Test-Path $k)) { continue }
        $p = Get-ItemProperty $k
        foreach ($name in ($p.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' })) {
            $exe = Resolve-Exe $name.Value; $tag = Get-SignatureTag $exe
            $lvl = if ($tag -match 'UNSIGNED|unknown|missing') { $flags++; 'warn' } else { 'info' }
            Write-Line ("  {0}\{1} -> {2}  [{3}]" -f ($k -replace '.*\\CurrentVersion\\',''), $name.Name, $exe, $tag) $lvl
        }
    }
    # Winlogon Shell / Userinit
    $wl = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -ErrorAction SilentlyContinue
    Write-Line 'Winlogon:'
    foreach ($n in 'Shell','Userinit') {
        $v = $wl.$n
        $ok = ($n -eq 'Shell' -and $v -eq 'explorer.exe') -or ($n -eq 'Userinit' -and $v -match 'userinit\.exe,?$')
        Write-Line ("  {0} = {1}" -f $n, $v) ($(if ($ok) {'info'} else {$flags++;'warn'}))
    }
    # Image File Execution Options - Debugger / SilentProcessExit hijacks
    Write-Line 'Image File Execution Options (debugger / silent-exit hijacks):'
    $ifeo = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
    $hit = $false
    Get-ChildItem $ifeo -ErrorAction SilentlyContinue | ForEach-Object {
        $d = (Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue).Debugger
        if ($d) { $hit = $true; $flags++; Write-Line ("  {0} -> Debugger = {1}" -f $_.PSChildName, $d) 'warn' }
    }
    $spe = "$ifeo\SilentProcessExit"
    if (Test-Path $spe) { Get-ChildItem $spe | ForEach-Object { $hit=$true; $flags++; Write-Line ("  SilentProcessExit: {0}" -f $_.PSChildName) 'warn' } }
    if (-not $hit) { Write-Line '  none' 'ok' }
    # Non-Microsoft scheduled tasks
    Write-Line 'Non-Microsoft scheduled tasks:'
    Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object {
        $_.State -ne 'Disabled' -and $_.TaskPath -notlike '\Microsoft\*' -and $_.TaskPath -ne '\'
    } | ForEach-Object {
        $exe = $null; try { $exe = ($_.Actions | Select-Object -First 1).Execute } catch {}
        Write-Line ("  {0}{1}  ({2})" -f $_.TaskPath, $_.TaskName, (Get-SignatureTag $exe))
    }
    Invoke-WmiScan -Quiet
    Write-Host ''
    if ($flags) { Write-Line "$flags item(s) worth a look (unsigned, non-standard, or a hijack). This audit changed nothing." 'warn' }
    else { Write-Line 'No unsigned or suspicious startup/persistence items found. Nothing changed.' 'ok' }
}

# ── MODULE 7: WMI & UEFI persistence scan (read-only) ─────────────────────────
function Invoke-WmiScan { param([switch]$Quiet)
    if (-not $Quiet) { Head 'WMI & UEFI persistence scan (read-only)' }
    Write-Line 'WMI permanent event subscriptions (root\subscription):'
    $any = $false
    foreach ($cls in '__EventFilter','CommandLineEventConsumer','ActiveScriptEventConsumer','__FilterToConsumerBinding') {
        Get-CimInstance -Namespace root\subscription -ClassName $cls -ErrorAction SilentlyContinue | ForEach-Object {
            $any = $true
            $detail = $_.Name; if ($_.CommandLineTemplate) { $detail += " -> $($_.CommandLineTemplate)" }
            if ($_.ScriptText) { $detail += ' -> [script]' }
            Write-Line ("  {0}: {1}" -f $cls, $detail) 'warn'
        }
    }
    if (-not $any) { Write-Line '  none (clean)' 'ok' }
    if ($Quiet) { return }
    # EFI System Partition - look for unexpected bootloaders
    Write-Line 'EFI System Partition bootloaders:'
    try {
        $mp = "$env:SystemDrive\JD-ESP-$PID"
        & mountvol $mp /S *> $null
        if (Test-Path "$mp\EFI") {
            Get-ChildItem "$mp\EFI" -Recurse -Include *.efi -ErrorAction SilentlyContinue | ForEach-Object {
                $known = $_.FullName -match '\\EFI\\(Microsoft|Boot)\\'
                Write-Line ("  {0}  [{1}]" -f ($_.FullName -replace [regex]::Escape($mp),'ESP:'), (Get-SignatureTag $_.FullName)) ($(if ($known){'info'}else{'warn'}))
            }
        }
        & mountvol $mp /D *> $null
    } catch { Write-Line "  Could not read the EFI partition ($($_.Exception.Message.Trim()))." 'warn' }
}

# ── MODULE 3: standby memory flush + cache cleanup ────────────────────────────
$script:MemTypeAdded = $false
function Add-MemType {
    if ($script:MemTypeAdded) { return }
    Add-Type -ErrorAction Stop -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class JdMem {
    [StructLayout(LayoutKind.Sequential)] struct LUID { public uint Lo; public int Hi; }
    [StructLayout(LayoutKind.Sequential)] struct LUID_AND_ATTR { public LUID Luid; public uint Attr; }
    [StructLayout(LayoutKind.Sequential)] struct TOKPRIV { public uint Count; public LUID_AND_ATTR Priv; }
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool OpenProcessToken(IntPtr h, uint a, out IntPtr t);
    [DllImport("advapi32.dll", SetLastError=true, CharSet=CharSet.Auto)] static extern bool LookupPrivilegeValue(string s, string n, out LUID l);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool AdjustTokenPrivileges(IntPtr t, bool d, ref TOKPRIV p, uint len, IntPtr prev, IntPtr plen);
    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
    [DllImport("ntdll.dll")] static extern int NtSetSystemInformation(int cls, IntPtr info, int len);
    const int SystemMemoryListInformation = 0x50; // 80
    static void Enable(string name) {
        IntPtr tok; OpenProcessToken(GetCurrentProcess(), 0x20|0x8, out tok);
        TOKPRIV tp = new TOKPRIV(); tp.Count = 1; tp.Priv.Attr = 0x2; // SE_PRIVILEGE_ENABLED
        LookupPrivilegeValue(null, name, out tp.Priv.Luid);
        AdjustTokenPrivileges(tok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
    }
    // command: 2=EmptyWorkingSets, 3=FlushModifiedList, 4=PurgeStandbyList
    public static int Run(int command) {
        Enable("SeProfileSingleProcessPrivilege");
        Enable("SeIncreaseQuotaPrivilege");
        IntPtr p = Marshal.AllocHGlobal(sizeof(int));
        Marshal.WriteInt32(p, command);
        int rc = NtSetSystemInformation(SystemMemoryListInformation, p, sizeof(int));
        Marshal.FreeHGlobal(p);
        return rc; // 0 = success (STATUS_SUCCESS)
    }
}
'@
    $script:MemTypeAdded = $true
}

function Invoke-MemoryFlush {
    Head 'Standby memory flush (native, no dummy allocations)'
    if ($script:DryRun) { Act 'empty working sets, flush the modified page list and purge the standby list'; return }
    try {
        Add-MemType
        $before = (Get-Counter '\Memory\Available MBytes' -ErrorAction SilentlyContinue).CounterSamples.CookedValue
        [void][JdMem]::Run(2); [void][JdMem]::Run(3)
        $rc = [JdMem]::Run(4)
        Start-Sleep -Milliseconds 400
        $after = (Get-Counter '\Memory\Available MBytes' -ErrorAction SilentlyContinue).CounterSamples.CookedValue
        if ($rc -eq 0) { Write-Line ("Standby list purged. Available RAM {0:N0} -> {1:N0} MB." -f $before, $after) 'ok' }
        else { Write-Line "NtSetSystemInformation returned 0x$($rc.ToString('X')) - run as Administrator." 'warn' }
    } catch { Write-Line "Memory flush failed: $($_.Exception.Message.Trim())" 'err' }
}

function Invoke-CacheClean {
    Head 'Targeted cache cleanup'
    $targets = @(
        @{ Name='User temp';            Path="$env:TEMP" },
        @{ Name='Windows temp';         Path="$env:windir\Temp" },
        @{ Name='Prefetch';             Path="$env:windir\Prefetch" },
        @{ Name='Windows Update cache';  Path="$env:windir\SoftwareDistribution\Download" },
        @{ Name='DirectX shader cache'; Path="$env:LOCALAPPDATA\D3DSCache" },
        @{ Name='NVIDIA shader cache';  Path="$env:LOCALAPPDATA\NVIDIA\DXCache" }
    )
    $freed = 0.0
    foreach ($t in $targets) {
        if (-not (Test-Path $t.Path)) { continue }
        $items = Get-ChildItem -LiteralPath $t.Path -Recurse -Force -ErrorAction SilentlyContinue
        $size  = ($items | Measure-Object Length -Sum -ErrorAction SilentlyContinue).Sum
        $mb    = [math]::Round(($size / 1MB), 1)
        if ($script:DryRun) { Write-Line ("WOULD clean {0}: ~{1} MB" -f $t.Name, $mb) 'warn'; continue }
        $n = 0
        foreach ($i in $items) { try { Remove-Item $i.FullName -Recurse -Force -ErrorAction Stop; $n++ } catch {} }
        $freed += $mb
        Write-Line ("{0}: ~{1} MB cleared ({2} items; files in use were skipped)." -f $t.Name, $mb, $n) 'ok'
    }
    if (-not $script:DryRun) { Write-Line ("About {0:N1} MB cleared in total." -f $freed) 'ok' }
}

# ── MODULE 4: game / heavy-workload service boost (snapshot + restore) ─────────
# Only ever SUSPEND these (stop + remember), never kernel-critical services. Restore puts them all back.
$script:BoostServices = @('SysMain','WSearch','Spooler','DiagTrack','MapsBroker','PhoneSvc')

function Invoke-ServiceBoost {
    Head 'Game / heavy-workload service boost'
    $list = $script:BoostServices + ($BoostApps | Where-Object { $_ })
    $snap = @()
    foreach ($svc in ($list | Select-Object -Unique)) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if (-not $s) { continue }
        $cfg = Get-CimInstance Win32_Service -Filter "Name='$svc'" -ErrorAction SilentlyContinue
        $snap += [pscustomobject]@{ Name=$svc; StartType=$cfg.StartMode; State=$s.Status.ToString() }
        if ($script:DryRun) { Act "stop $svc (will be restored on exit)"; continue }
        try { if ($s.Status -eq 'Running') { Stop-Service $svc -Force -ErrorAction SilentlyContinue }
              Write-Line "Paused $svc." 'ok' } catch { Write-Line "Could not pause $svc." 'warn' }
    }
    Save-Json 'boost-snapshot.json' $snap
    if (-not $script:DryRun) { Write-Line 'Services paused and saved to a snapshot. Run "services-restore" (or Restore everything) to put them back exactly.' 'ok' }
}

function Restore-ServiceBoost {
    Head 'Restore boosted services'
    $f = Join-Path $script:SnapshotDir 'boost-snapshot.json'
    if (-not (Test-Path $f)) { Write-Line 'No boost snapshot found - nothing to restore.' 'warn'; return }
    foreach ($svc in (Get-Content $f -Raw | ConvertFrom-Json)) {
        if ($script:DryRun) { Act "restore $($svc.Name) to $($svc.StartType)/$($svc.State)"; continue }
        try {
            $map = @{ Auto='Automatic'; Manual='Manual'; Disabled='Disabled' }
            if ($map[$svc.StartType]) { Set-Service $svc.Name -StartupType $map[$svc.StartType] -ErrorAction SilentlyContinue }
            if ($svc.State -eq 'Running') { Start-Service $svc.Name -ErrorAction SilentlyContinue }
            Write-Line "Restored $($svc.Name)." 'ok'
        } catch { Write-Line "Could not restore $($svc.Name)." 'warn' }
    }
    if (-not $script:DryRun) { Remove-Item $f -ErrorAction SilentlyContinue }
}

# ── MODULE 5: Microsoft Defender hardening + ASR + HVCI ───────────────────────
$script:AsrRules = [ordered]@{
    '9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2' = 'Block credential theft from lsass.exe'
    'd4f940ab-401b-4efc-aadc-ad5f3c50688a' = 'Block Office apps creating child processes'
    'b2b3f03d-6a65-4f7b-a9c7-1c7ef74a9ba4' = 'Block untrusted/unsigned processes from USB'
    '5beb7efe-fd9a-4556-801d-275e5ffc04cc' = 'Block potentially obfuscated scripts'
    'be9ba2d9-53ea-4cdc-84e5-9b1eeee46550' = 'Block executable content from email/webmail'
}

function Invoke-DefenderHardening {
    param([switch]$Enforce)   # default = ASR in AUDIT mode (nothing blocked yet)
    Head ("Microsoft Defender hardening" + $(if ($Enforce) {' (ENFORCE)'} else {' (audit mode)'}))
    try { $mp = Get-MpPreference -ErrorAction Stop } catch { Write-Line 'Microsoft Defender is not available (third-party AV installed?). Skipped.' 'warn'; return }

    Save-Json 'defender-before.json' @{
        CloudBlockLevel = "$($mp.CloudBlockLevel)"; CloudExtendedTimeout = $mp.CloudExtendedTimeout
        PUAProtection = "$($mp.PUAProtection)"; EnableNetworkProtection = "$($mp.EnableNetworkProtection)"
        ASR = @{ Ids = $mp.AttackSurfaceReductionRules_Ids; Actions = $mp.AttackSurfaceReductionRules_Actions }
    }
    if ($script:DryRun) {
        Act 'Cloud block level High, extended timeout 50s, PUA on, Network Protection on'
        Act ("add " + $script:AsrRules.Count + " ASR rules in " + $(if ($Enforce){'Block'}else{'Audit'}) + ' mode')
    } else {
        try {
            Set-MpPreference -MAPSReporting Advanced -SubmitSamplesConsent SendSafeSamples -ErrorAction SilentlyContinue
            Set-MpPreference -CloudBlockLevel High -CloudExtendedTimeout 50 -ErrorAction SilentlyContinue
            Set-MpPreference -PUAProtection Enabled -ErrorAction SilentlyContinue
            Set-MpPreference -EnableNetworkProtection ($(if ($Enforce) {'Enabled'} else {'AuditMode'})) -ErrorAction SilentlyContinue
            Write-Line 'Cloud block High, extended timeout 50s, PUA on, Network Protection set.' 'ok'
            $action = if ($Enforce) { 'Enabled' } else { 'AuditMode' }
            foreach ($id in $script:AsrRules.Keys) {
                Add-MpPreference -AttackSurfaceReductionRules_Ids $id -AttackSurfaceReductionRules_Actions $action -ErrorAction SilentlyContinue
                Write-Line ("ASR [{0}] {1}: {2}" -f $action, $script:AsrRules[$id], $id) 'ok'
            }
            if (-not $Enforce) { Write-Line 'ASR rules are in AUDIT mode - they only log for now. Re-run "defender-enforce" once the log is clean to block.' 'warn' }
        } catch { Write-Line "Defender hardening error: $($_.Exception.Message.Trim())" 'err' }
    }
    # HVCI / Core Isolation status (report only)
    $hvci = (Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard -ErrorAction SilentlyContinue).SecurityServicesRunning
    if ($hvci -contains 2) { Write-Line 'HVCI (Memory integrity / Core isolation) is ON.' 'ok' }
    else { Write-Line 'HVCI (Memory integrity) is OFF. Turn it on in Windows Security > Device security > Core isolation (needs a reboot). Note: it adds a little overhead to emulators/VMs.' 'warn' }
}

function Restore-Defender {
    $f = Join-Path $script:SnapshotDir 'defender-before.json'
    if (-not (Test-Path $f)) { return }
    if ($script:DryRun) { Act 'remove the ASR rules JD-Sentinel added'; return }
    foreach ($id in $script:AsrRules.Keys) { Remove-MpPreference -AttackSurfaceReductionRules_Ids $id -ErrorAction SilentlyContinue }
    Write-Line 'ASR rules added by JD-Sentinel removed. Cloud/PUA settings left on (they are safe); set them in Windows Security if you want them off.' 'ok'
}

# ── MODULE 6: behavioural watchdog - ALERT ONLY ───────────────────────────────
# Deploys read-only canary files and watches for (a) canary tampering / high-entropy bursts and
# (b) office/browser -> shell exploit chains. It only WARNS (and can snapshot VSS); it never
# suspends or kills, so it can never freeze your game or a legitimate app.
function Get-CanaryPaths {
    @("$([Environment]::GetFolderPath('MyDocuments'))\~JD_DO_NOT_DELETE.txt",
      "$([Environment]::GetFolderPath('Desktop'))\~JD_DO_NOT_DELETE.txt")
}
function Deploy-Canaries {
    $hashes = @{}
    foreach ($p in Get-CanaryPaths) {
        try {
            if (-not (Test-Path $p)) {
                Set-Content -LiteralPath $p -Value "JD-Sentinel ransomware canary. Do not edit or delete. $(Get-Date -Format s)" -Encoding utf8
                (Get-Item $p).Attributes = 'Hidden'
            }
            $hashes[$p] = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash
        } catch {}
    }
    return $hashes
}
function New-ShadowCopy {
    try { & vssadmin create shadow /for=$env:SystemDrive *> $null; Write-Line 'Created a Volume Shadow Copy restore point.' 'ok' }
    catch { Write-Line 'Could not create a shadow copy.' 'warn' }
}
$script:ExploitParents = 'WINWORD.EXE','EXCEL.EXE','POWERPNT.EXE','OUTLOOK.EXE','chrome.exe','msedge.exe','firefox.exe','AcroRd32.exe'
$script:ExploitChildren = 'powershell.exe','pwsh.exe','cmd.exe','wscript.exe','cscript.exe','mshta.exe','certutil.exe','bitsadmin.exe'

function Invoke-Watchdog {
    Head 'Behavioural watchdog (ALERT ONLY - never suspends anything)'
    Write-Line 'Deploying canary files and watching. Press Ctrl+C to stop.'
    $canary = Deploy-Canaries
    foreach ($p in $canary.Keys) { Write-Line "  canary: $p" }
    Write-Line ("Watching for exploit chains: {0} spawning {1}." -f ($script:ExploitParents -join '/'), ($script:ExploitChildren -join '/'))
    $seen = @{}
    while ($true) {
        Start-Sleep -Seconds 3
        # (a) canary integrity
        foreach ($p in @($canary.Keys)) {
            if (-not (Test-Path $p)) { Write-Line "CANARY DELETED: $p  - possible ransomware! Check running apps now." 'err'; if (-not $script:DryRun) { New-ShadowCopy }; $canary = Deploy-Canaries; continue }
            $h = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash
            if ($h -ne $canary[$p]) { Write-Line "CANARY MODIFIED: $p  - possible ransomware! Check running apps now." 'err'; if (-not $script:DryRun) { New-ShadowCopy }; $canary[$p] = $h }
        }
        # (b) parent -> child exploit chains
        try {
            Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $script:ExploitChildren -contains $_.Name } | ForEach-Object {
                $child = $_; $key = "$($child.ProcessId)"
                if ($seen.ContainsKey($key)) { return }
                $parent = Get-CimInstance Win32_Process -Filter "ProcessId=$($child.ParentProcessId)" -ErrorAction SilentlyContinue
                if ($parent -and $script:ExploitParents -contains $parent.Name) {
                    $seen[$key] = $true
                    Write-Line ("EXPLOIT CHAIN: {0} (pid {1}) spawned {2} (pid {3}). Command: {4}" -f `
                        $parent.Name, $parent.ProcessId, $child.Name, $child.ProcessId, ($child.CommandLine)) 'err'
                    Write-Line '  -> alert only. If you did not start this, close those apps and run a Defender scan.' 'warn'
                }
            }
            if ($seen.Count -gt 500) { $seen = @{} }
        } catch {}
    }
}

# ── restore everything ────────────────────────────────────────────────────────
function Restore-All {
    Head 'Restore everything JD-Sentinel changed'
    # services (debloat + boost)
    foreach ($name in 'debloat-services.json','boost-snapshot.json') {
        $f = Join-Path $script:SnapshotDir $name
        if (-not (Test-Path $f)) { continue }
        foreach ($svc in (Get-Content $f -Raw | ConvertFrom-Json)) {
            if ($script:DryRun) { Act "restore service $($svc.Name)"; continue }
            $map = @{ Auto='Automatic'; Manual='Manual'; Disabled='Disabled' }
            if ($map[$svc.StartType]) { Set-Service $svc.Name -StartupType $map[$svc.StartType] -ErrorAction SilentlyContinue }
            if ($svc.State -eq 'Running') { Start-Service $svc.Name -ErrorAction SilentlyContinue }
            Write-Line "Restored service $($svc.Name)." 'ok'
        }
        if (-not $script:DryRun) { Remove-Item $f -ErrorAction SilentlyContinue }
    }
    # power plan
    $pf = Join-Path $script:SnapshotDir 'power-plan.json'
    if (Test-Path $pf) {
        $prev = (Get-Content $pf -Raw | ConvertFrom-Json).Previous
        if ($script:DryRun) { Act "switch the power plan back to $prev" }
        elseif ($prev) { & powercfg /setactive $prev *> $null; Write-Line 'Power plan restored.' 'ok'; Remove-Item $pf -ErrorAction SilentlyContinue }
    }
    Restore-Defender
    # registry: revert each value to exactly what it was (restore old data, or remove values we created)
    $rf = Join-Path $script:SnapshotDir 'debloat-reg.json'
    if (Test-Path $rf) {
        foreach ($u in (Get-Content $rf -Raw | ConvertFrom-Json)) {
            if ($script:DryRun) { Act "revert $($u.Path)\$($u.Name)"; continue }
            try {
                if ($u.Existed) { Set-ItemProperty -Path $u.Path -Name $u.Name -Value $u.Old -ErrorAction SilentlyContinue }
                else { Remove-ItemProperty -Path $u.Path -Name $u.Name -ErrorAction SilentlyContinue }
            } catch {}
        }
        Write-Line 'Registry values restored to their original state.' 'ok'
        if (-not $script:DryRun) { Remove-Item $rf -ErrorAction SilentlyContinue }
    }
    # any whole-key .reg backups too, then remove canaries
    if (-not $script:DryRun) {
        if (Test-Path $script:BackupBase) {
            Get-ChildItem $script:BackupBase -Recurse -Filter *.reg -ErrorAction SilentlyContinue | ForEach-Object { & reg.exe import $_.FullName *> $null }
        }
        foreach ($p in Get-CanaryPaths) { Remove-Item $p -Force -ErrorAction SilentlyContinue }
    }
    Write-Line 'Restore complete. A reboot is a good idea so every service state settles.' 'ok'
}

# ── menu ───────────────────────────────────────────────────────────────────────
function Show-Menu {
    while ($true) {
        Write-Host ''
        Write-Line ('JD-SENTINEL' + $(if ($script:DryRun) {'   (AUDIT-ONLY: nothing will be changed)'} else {''})) 'head'
        Write-Host '  1  Debloat & telemetry + Ultimate Performance plan   (reversible)'
        Write-Host '  2  Audit startup / persistence - Run, IFEO, tasks, WMI (read-only)'
        Write-Host '  3  Flush standby RAM'
        Write-Host '  4  Clean caches (temp, prefetch, update, shader)'
        Write-Host '  5  Game boost: pause background services (snapshot)'
        Write-Host '  6  Restore boosted services'
        Write-Host '  7  Harden Microsoft Defender  (ASR in AUDIT mode)'
        Write-Host '  8  Harden Defender + ENFORCE ASR rules  (may block unsigned apps)'
        Write-Host '  9  Scan WMI & EFI for persistence (read-only)'
        Write-Host ' 10  Behavioural watchdog (alert only; Ctrl+C to stop)'
        Write-Host '  R  Restore EVERYTHING JD-Sentinel changed'
        Write-Host "  A  Toggle audit-only mode (now: $($script:DryRun))"
        Write-Host '  0  Exit'
        $c = Read-Host '  Choose'
        switch ($c) {
            '1' { Invoke-Debloat } '2' { Invoke-Autoruns } '3' { Invoke-MemoryFlush } '4' { Invoke-CacheClean }
            '5' { Invoke-ServiceBoost } '6' { Restore-ServiceBoost } '7' { Invoke-DefenderHardening }
            '8' { Invoke-DefenderHardening -Enforce } '9' { Invoke-WmiScan } '10' { Invoke-Watchdog }
            'R' { Restore-All } 'r' { Restore-All }
            'A' { $script:DryRun = -not $script:DryRun } 'a' { $script:DryRun = -not $script:DryRun }
            '0' { return } default { }
        }
        if ($c -ne '10') { Write-Host ''; Read-Host '  Press Enter' | Out-Null }
    }
}

# ── entry point ────────────────────────────────────────────────────────────────
if (-not (Test-Admin)) {
    if ($NonInteractive) { Write-Line 'JD-Sentinel needs Administrator. Re-run elevated.' 'err'; exit 1 }
    Write-Line 'Re-launching as Administrator...' 'warn'
    $argline = @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$PSCommandPath`"")
    if ($AuditOnly) { $argline += '-AuditOnly' }
    if ($Action -ne 'menu') { $argline += @('-Action', $Action) }
    Start-Process (Get-Process -Id $PID).Path -Verb RunAs -ArgumentList $argline
    exit 0
}

Initialize-Session
Write-Line "JD-Sentinel  -  backups under $script:BackupBase" 'head'
if (-not $script:DryRun -and $Action -in 'debloat','defender','defender-enforce') { New-RestorePoint }

switch ($Action) {
    'menu'              { Show-Menu }
    'debloat'           { Invoke-Debloat }
    'restore'           { Restore-All }
    'memory'            { Invoke-MemoryFlush }
    'clean'             { Invoke-CacheClean }
    'services-boost'    { Invoke-ServiceBoost }
    'services-restore'  { Restore-ServiceBoost }
    'defender'          { Invoke-DefenderHardening }
    'defender-enforce'  { Invoke-DefenderHardening -Enforce }
    'autoruns'          { Invoke-Autoruns }
    'scan'              { Invoke-WmiScan }
    'watch'             { Invoke-Watchdog }
}
