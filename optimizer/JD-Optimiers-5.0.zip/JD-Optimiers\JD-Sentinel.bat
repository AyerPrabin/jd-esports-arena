@echo off
:: JD-Sentinel - Windows optimisation & behavioural-security companion for JD-Optimiers.
:: Opens the menu (self-elevates to Administrator). Use PowerShell 7 (pwsh) if present, else Windows PowerShell.
setlocal
set "PS=powershell"
where pwsh >nul 2>nul && set "PS=pwsh"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0JD-Sentinel.ps1" %*
