# JD-Sentinel

A single, dependency-free PowerShell companion to JD-Optimiers: the useful low-level tricks of the big
"optimiser" and security tools, but **safe and reversible**. No Electron, no Python, no background bloat.

Run **`JD-Sentinel.bat`** (self-elevates to Administrator) for the menu, or headless:

```
pwsh -File JD-Sentinel.ps1 -AuditOnly          # menu; every destructive item becomes a dry run
pwsh -File JD-Sentinel.ps1 -Action debloat      # run one module without the menu
```

Headless actions: `debloat restore memory clean services-boost services-restore defender
defender-enforce autoruns scan watch`.

## What it does

| # | Module | Safe by design |
|---|--------|----------------|
| 1 | Debloat & telemetry (DiagTrack, dmwappushservice, consumer features, Copilot, **Recall**, Bing/Cortana) + **Ultimate Performance** plan + PCIe ASPM off | Every service state and registry value is recorded first; **Restore** puts them back exactly |
| 2 | Startup / persistence **audit** — Run/RunOnce (HKLM/HKCU/WOW64), Winlogon, IFEO debugger & SilentProcessExit, non-MS scheduled tasks, WMI subscriptions; Authenticode signature of each | Read-only; flags unsigned / non-Microsoft / hijacks |
| 3 | Standby-RAM flush via native `NtSetSystemInformation` (no dummy allocations) + targeted cache cleanup (temp, prefetch, Windows Update, DirectX/NVIDIA shader) | Flush is transient; cleanup only touches known cache dirs and skips files in use |
| 4 | Game / heavy-workload service boost (SysMain, WSearch, Spooler, DiagTrack, MapsBroker, PhoneSvc) | Pre-boost state saved to JSON; `services-restore` (or Restore) puts every service back exactly |
| 5 | Microsoft Defender hardening — cloud block **High**, extended timeout **50s**, PUA, Network Protection, **ASR rules**, HVCI status | **ASR goes on in Audit mode first** (nothing blocked). `defender-enforce` switches to Block once the audit log is clean. Restore removes the rules JD-Sentinel added |
| 6 | Behavioural watchdog — ransomware **canary** files + **exploit-chain** detection (Office/browser → powershell/cmd/certutil…) | **Alert only.** It warns (and can make a VSS shadow copy); it **never** suspends or kills a process, so it can't freeze your game or a legitimate app |
| 7 | WMI (`root\subscription`) & **EFI System Partition** persistence scan | Read-only |

## Safety model

- **Administrator required.** On a destructive run it first makes a **System Restore point**.
- Every service change, power-plan change, Defender rule and registry value is recorded under
  `JD-Sentinel-backups\<timestamp>\` and `JD-Sentinel-state\`. **Menu → R (Restore everything)** reverts all
  of it: service start-types and states, the previous power plan, the ASR rules, and every registry value
  (restoring old data, or removing values JD-Sentinel created). Canary files are removed too.
- `--AuditOnly` and the "Audit" menu items change nothing — they print what they *would* do.
- The ASR GUIDs, memory-list constants and service list are the documented Microsoft values (see the header
  of `JD-Sentinel.ps1`).

## What is **not** done, on purpose

- **No auto-suspend / auto-kill.** The spec's "suspend the process on a canary hit / exploit chain" is
  shipped as an **alert**. On a gaming PC, auto-suspending on a heuristic would eventually freeze the
  emulator, a game updater, OBS or a backup tool on a false positive — the exact stability/ban risk
  JD-Optimiers must never take.
- **No Python daemon.** The watchdog is PowerShell, so there's nothing extra to install for players.
- **ASR enforced only when you choose it** (`defender-enforce`), because "block unsigned processes" can stop
  the emulator and some game launchers until you allow them.
