JD-Optimiers v4.2 (app window) - Mouse control + FPS booster for MSI App Player / BlueStacks 5 (Free Fire)
==========================================================================================

HOW TO USE
  Double-click JD-Optimiers.exe (or Run-as-Admin.bat) - the app window opens.

  NEW IN 4.2 - any game, performance modes, lower prices
    - New prices: Optimizer Pro 49 points, Optimizer Max 99 points (30 days). Max now also gives
      a 30-day Pro squad effect each time you buy, early entry to marked tournaments/rooms, and a
      verified checkmark next to your name - on top of Panel scan.
    - Boost ANY PC game, not just Free Fire: press "Games" to add a game's .exe, or leave
      auto-detect on and any full-screen game is boosted automatically.
    - Performance Mode button:
        Balanced - the normal boost.
        Extreme  - pauses Windows background services (SysMain, Search, telemetry) and runs the
                   CPU at full speed while you play (plugged in). More heat - keep the PC cool.
                   Needs Administrator. Everything is put back when the boost ends.
        Potato   - Extreme, plus "Apply best profile" drops the emulator to 1280x720 / 60 FPS for
                   weak PCs.
    - Your plan shows as a PRO / MAX chip in the title bar.

  NEW IN 4.1 - JD Esports Arena account + Optimizer Pro / Max
    - JD-Optimiers now needs a plan on your JD Esports Arena account (jdesport.co.uk), paid with
      JD points (1 point = Rs 1, loaded on the site's wallet with eSewa):
        Optimizer Pro  100 points / 30 days - everything except Panel scan
        Optimizer Max  170 points / 30 days - everything + Panel scan
      Buy at https://jdesport.co.uk/optimizer/ (sign in first). Buying again adds 30 days.
    - Sign in once per PC: the app shows a code (like ABCD-2345) and opens the website - sign in
      there (email or Google), check the code matches, press "Link this PC". No password is typed
      into the app. 2 PCs per account; unlink old PCs on the plans page.
    - The plan is checked when the app starts. Without internet it keeps working for up to 3 days
      after the last check (while the plan is active).
    - No plan? The app's start screen still lets you "Restore settings" (puts back everything
      JD-Optimiers changed). Tray menu > "Sign out of this PC" unlinks it.
    - The console version (JD-Optimiers-Console.exe) is no longer part of the download.

  NEW IN 4.0 - JD Esports logo + automatic updates
    - The JD Esports Arena logo (same as jdesport.co.uk) in the window, splash, tray and app icon.
    - Download / reinstall: https://jdesport.co.uk/optimizer/
    - Updates are required: at every start the app checks jdesport.co.uk. If a new version is out,
      a pop-up offers "Update now" (or exit). It downloads, checks the file (SHA-256), swaps itself
      and reopens in a few seconds. It only checks when the app starts - never during a match.
      If the site can't be reached (no internet), the app still opens and says so in the feed.

  NEW IN 3.9 - JD Esports gold look + more GPU for graphics
    - New colors matching jdesport.co.uk: near-black background, gold buttons with dark text,
      Bahnschrift Condensed headings (closest Windows font to the site's Barlow Condensed).
    - Windows tweaks (also run by Play the first time) now add, when the Administrator prompt
      is accepted: Hardware-accelerated GPU scheduling ON (needs a PC restart) and the Windows
      "Games" scheduler profile (GPU priority 8, scheduling High). Restore all undoes both.
    - "Apply best profile" on a high-end PC with a graphics card, on the charger, also raises
      the emulator resolution 1600x900 / 1280x720 -> 1920x1080 (sharper, more GPU work). It is
      listed in the confirm box; MSI App Player must be closed. Restore all puts it back.
    - Free Fire's own Graphics level (Smooth / Standard / Ultra) is set inside the game by you.

  NEW IN 3.8 - real FPS numbers
    - Live FPS while you play (uses PresentMon from the fps-monitor folder - it reads
      Windows' frame events, nothing inside the game). Needs the Administrator prompt.
    - The session report now shows FPS: average, 1% low (the dips you feel as lag) and
      stutters per minute - and compares with your last match:
        "vs last session: FPS 75 -> 84, 1% low 28 -> 52"
      plus which settings changed in between. All sessions: Console --history
    - Renderer test: with MSI App Player closed, Console --renderer vulkan (or opengl),
      play one match, compare. --astc off|software the same way. Restore all undoes it.
    - Laptop checks: report warns when you played on battery or the NVIDIA card slowed
      itself down because of heat.
    - Console --pc-check (changes nothing): power mode, GPU scheduling, Memory Integrity,
      emulator graphics, macro keys. JD-Optimiers will NOT turn off Memory Integrity -
      it only tells you.
    - Console --remove-macros lists your macro keys (ban risk); --remove-macros yes
      deletes them from the Free Fire controls (MSI App Player closed, backup made,
      Restore all puts them back). REDRAGON rapid-fire must be changed in the REDRAGON app.
    - Ping line now says what it pings. Matches run over UDP, which Windows cannot show,
      so the ping is a guide - not the exact match ping.

  NEW LOOK (3.7)
    - JD brand look: deep navy with the JD gradient (cyan -> blue -> violet) and a
      matching JD icon.
    - The log is now an easy-to-read activity list: green check = done, yellow ! =
      look at this, red x = problem. Scroll with the mouse wheel; right-click it to
      copy everything.

  NEW IN 3.7 - Panel scan finds more
    - Programs run in the last days, even if closed or deleted before the scan
      (Windows activity log - needs the Administrator prompt accepted).
    - Local proxy and hosts-file redirects of Free Fire / Garena servers.
    - DEEP SCAN (Shift+click Panel scan, or --scan deep): also lists the DLLs loaded
      inside the emulator and flags unsigned ones (injected panels). This reads the
      emulator's DLL list like Task Manager does - no game data - so it only runs
      when you ask for it.

  NEW IN 3.6
    - Point at any button: the strip above the log says what it does. Not pointing
      at anything: "Setup check" says what to fix next (green = all good).
    - Knows your PC: Low-end / Mid-range / High-end, laptop or desktop (shown at
      the top). The best profile, FPS choice and tips fit that PC - e.g. 2 emulator
      cores + 60 FPS on a 4 GB laptop, no "dedicated GPU" on PCs without one.
    - Temperature tile also works on AMD / Intel PCs ("system °C").
    - Windows tweaks also bypass fullscreen optimizations and stop Store apps
      running in the background (their notifications stop - Restore all undoes it).
    - Clearer names: "Mouse accel (keep OFF)", "Apply best profile".

  NEW IN 3.5
    - Start with Windows now uses Task Scheduler: no admin prompt at login, also
      on battery. Old "Start with Windows" entries are moved over automatically.
    - Scan reports end with "Seal: XXXX-XXXX-XXXX-XXXX". Check one with
        JD-Optimiers-Console.exe --verify "JD-Scan-....txt"
      VALID = untouched, INVALID = someone edited it. (Shows edits; a determined
      hacker could still fake one - for real certainty, scan the PC yourself.)
    - Mouse card shows the emulator aim values: "Aim X 2.04 · Y 91%".
    - Panel scan button shows the last result (clean / warning / CHEAT).
    - Finds MSI App Player / BlueStacks even when installed on another drive.

  NEW IN 3.4
    - Starts as administrator by itself (one Windows prompt). Say No and it still
      runs, only RAM purge / full panel scan / priority may be limited.
      Starting it again while it runs just brings the window forward (no prompt).
    - Boost clears the Windows standby RAM once, and stops Windows 11 power
      throttling (EcoQoS) for HD-Player.exe while it has HIGH priority.
    - Ping tile pings the server the emulator is connected to ("game server");
      if it ignores ping, or there is no connection yet, 1.1.1.1 ("internet").
    - Laptop profile also sets High FPS ON, VSync OFF, Prefer dedicated GPU ON,
      and has a 240 FPS choice (only useful on 144 Hz+ screens).
    - Windows tweaks: HD-Player.exe gets "DPI scaling: Application" and
      fullscreen optimizations OFF (its Properties > Compatibility settings).
    - Aim fix keeps a custom up/down ratio (40-250%) and only turns emulator
      mouse acceleration OFF. Set X / Y yourself: Console --aim-xy 2.04 0.91
    - Only scripts that fire several taps count as macros (helper scripts don't).

  NEW IN 3.2 / 3.3 - glass look, Panel scan, app icon
    Dark "liquid glass" window (frosted panels over a soft orange / purple glow,
    iOS-style switches that slide) and an animated JD splash when the app opens
    (click it to skip). It looks the same whether Windows transparency is on or off.
    The window stops redrawing while the game is in front, so it costs no FPS.
    No splash when it starts in the tray (Start with Windows / --tray).

  PLAY FREE FIRE (big orange button)
    optimizes Windows -> opens MSI App Player straight into Free Fire ->
    Boost + App Sleep while you play -> when you close MSI App Player it
    stops by itself, wakes your apps and writes a SESSION REPORT in the log.
    "Desktop shortcut" makes an icon "Play Free Fire (JD)" that does the same.

  AUTO MODE (zero clicks)
    Turn on "Auto boost when game opens" (and "Start with Windows" if you like).
    JD-Optimiers then waits in the system tray. Open MSI App Player any way you
    like -> boost starts by itself -> close it -> boost stops, apps wake up and
    a Windows notification shows your match summary (time, GPU, temp, ping).
    With Auto mode on, the X button hides the window to the tray.
    Tray icon: click = open, right-click = Play / Auto on-off / Exit.

  LEFT SIDE
    Boost only        - boost without launching the game (press again to stop)
    Restore all       - puts back everything JD-Optimiers changed
    Live tiles        - CPU, GPU load (which GPU runs the game), GPU temp, ping,
                        each with a 60-second graph; RAM bar; apps asleep
    Log               - what the app did + session report and advice

  RIGHT SIDE
    Mouse sensitivity - drag the slider or use - / +, presets, pointer precision
    Gaming boost      - App Sleep, Auto boost, Start with Windows, sleep list,
                        Windows tweaks (your choices are remembered)
    Laptop profile    - pick 60 / 90 / 120 FPS and apply (emulator must be closed)

  FILES
    JD-Optimiers.exe          the app window
    JD-Optimiers-Console.exe  same features in a text menu + command line
    gui.c / jd_optimiers.c    source code, build.bat rebuilds both

LIVE STATS WHILE PLAYING (console shows the same in one line)
    - RTX 3050 = the game is on your NVIDIA card (good). "Radeon" = it is not.
    - 62C = NVIDIA GPU temperature ("HOT" at 85C+)
    - Ping = the game server the emulator is connected to, or 1.1.1.1 when that
      server ignores ping (the tile says which).
      If Net jumps/LOST while the game lags, the lag is the internet, not FPS.

  SESSION REPORT (after each Play / Boost)
    Average/peak CPU, RAM, GPU load, GPU temperature and ping, plus advice:
    game on the wrong GPU, GPU maxed out (lower FPS cap), running hot,
    CPU/RAM too busy, or internet spikes.

WHAT IT CHANGES (Play applies the Windows tweaks automatically the first time)
  - Mouse pointer speed (1-20, 10 = default) and Enhance Pointer Precision
  - Power plan -> Ultimate / High Performance
  - HD-Player.exe priority -> HIGH (never Realtime)
  - 1 ms system timer + no sleep while Boost Mode is running
  - Windows gaming tweaks: Game Mode ON, Xbox Game Bar recording OFF,
    emulator forced onto the high-performance GPU, transparency and
    window animations OFF, pointer trails OFF
  - Closes background apps only if you answer "y" for each one
  - APP SLEEP (in Boost Mode): apps on your sleep list are paused (0% CPU)
    and their RAM is freed while the game window is in front. Alt-Tab out
    or stop Boost and they wake up instantly. Edit the list in
    Optimizer > [7] or in JD-Optimiers-sleep-list.txt. Discord/Spotify are
    not on it by default so voice chat and music keep working.
    If the PC crashes while apps are asleep, just open JD-Optimiers again
    (or run JD-Optimiers.exe --wake) and they are woken up automatically.

  - PANEL SCAN (button "Panel scan", Console [7] or --scan) - for players and
    tournament organizers. Looks for signs of cheat panels and hardcode hacks:
      * windows drawn over the game, especially ones hidden from screenshots
        (how ESP / aim panels draw)
      * programs that can write into the emulator's memory (how injected panels
        work) - needs admin: start with Run-as-Admin.bat for a full scan
      * cheat tools / unsigned "panel" programs running from Downloads or Temp
      * Windows test-signing or debug mode (kernel-level panels need it)
      * emulator root / ADB on, macro keys, mouse rapid-fire buttons
      * modded APK / OBB files in Downloads, Desktop and the emulator shared folder
    Result: NO SIGNS FOUND / PARTIAL SCAN (some checks could not run) / WARNING /
    CHEAT SIGNS FOUND, with the evidence for each finding. A report file
    JD-Scan-<date>-<time>.txt is saved next to the app (PC name, user, time).
    Open the game first so the overlay and write-access checks can run.
    LIMIT: game files inside the emulator cannot be checked from Windows - the
    scan shows warning signs, it cannot prove the game files are clean.
    It only reads; it never opens the game's memory and never changes anything.

  - AIM FIX (button next to Pointer precision, or Console --aim [fix]):
    checks Windows mouse settings, the emulator screen size, your Free Fire
    game controls and the REDRAGON mouse app profile. It fixes only aim feel:
    up/down aim set to 100% of left/right (a lower value makes drags to the head
    fall short, so aim stays low) and emulator mouse acceleration OFF.
    MSI App Player must be closed for that; backup JD-Optimiers-keymap.cfg.bak,
    Restore all puts it back. Screen size is only checked (your buttons are placed
    for it). It warns about macros (script keys, REDRAGON rapid-fire buttons) because
    Garena bans them - it never adds macros or aim help. REDRAGON settings are only
    read; it opens the REDRAGON app so you change them there.
  - LAPTOP PROFILE (only if you choose it): the emulator's RAM and FPS cap
    in C:\ProgramData\BlueStacks_msi5\bluestacks.conf - the same values as
    its Settings screen. RAM is set to what Free Fire needs (4 GB on a 16 GB
    PC) so Windows keeps the rest; you pick the FPS cap (60 / 90 / 120).
    Nothing else in that file is touched. Original saved as
    JD-Optimiers-bluestacks.conf.bak and put back exactly by Restore.
  - BOOST MODE shows live CPU %, RAM used and which GPU the game is on + its load,
    so you can see the NVIDIA card doing the work.

  Your original settings are saved to JD-Optimiers-backup.ini the first time
  something is changed. Restore uses that file.

SAFE FOR ANTI-CHEAT
  It only changes Windows settings, other apps (browsers, launchers...) and,
  if you choose Laptop profile, the emulator's RAM/FPS settings (same as its
  Settings screen). It never opens, reads or changes Free Fire or the
  emulator's memory, and the emulator is never paused. No macros, no aim or recoil help,
  no injected code - it is the same as changing settings in Windows yourself.

COMMAND LINE
  JD-Optimiers-Console.exe --status | --mouse N | --accel on|off | --optimize | --tweaks | --play | --shortcut | --boost | --wake | --profile | --aim [fix] | --aim-xy X Y | --scan [deep] | --verify FILE | --pc-check | --fps [secs] | --history | --renderer opengl|vulkan | --astc off|software | --remove-macros [yes] | --restore

REBUILD
  build.bat   (icon + version info come from res\jd.rc / res\jd.ico)
    (needs GCC: winget install BrechtSanders.WinLibs.POSIX.UCRT)
